package com.kacper.itemxxx.fragment.loginAndregister

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.kacper.itemxxx.R
import com.kacper.itemxxx.ui.mainactivity.MainActivity
import kotlinx.android.synthetic.main.activity_panel.*

class PanelActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_panel)


        val userId = intent.getStringExtra("user_id")
        val emailId = intent.getStringExtra("email_id")

        tv_user_id.text = " $userId" //Firebase auth ID users
        tv_email_id.text = " $emailId"


        btn_change.setOnClickListener {
            val intent = Intent(this, ChangePasswordActivity::class.java)
            startActivity(intent)
        }

        // LOGOUT
        btn_logout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()

            startActivity(Intent(this@PanelActivity, LoginActivity::class.java))
            finish()
        }

        // Next to scanner and you rent equipment
        btn_scanner.setOnClickListener {

            val aktiv = Intent(applicationContext, MainActivity::class.java)
            startActivity(aktiv)
        }



    }


}


