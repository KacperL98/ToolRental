package com.kacper.itemxxx.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.kacper.itemxxx.R
import com.kacper.itemxxx.fragment.loginAndregister.LoginActivity
import com.kacper.itemxxx.fragment.loginAndregister.RegisterActivity
import kotlinx.android.synthetic.main.fragment_home.*

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)





        login.setOnClickListener {
            activity?.finish()
            startActivity(
                LoginActivity.prepareIntent(
                    requireContext()
                )
            )
        }

        register2.setOnClickListener {
            activity?.finish()
            startActivity(
                RegisterActivity.prepareIntent(
                    requireContext()
                )
            )
        }
    }
}
