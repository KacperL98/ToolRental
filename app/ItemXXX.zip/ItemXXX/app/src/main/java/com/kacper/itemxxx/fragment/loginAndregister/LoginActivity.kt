package com.kacper.itemxxx.fragment.loginAndregister

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.kacper.itemxxx.R
import kotlinx.android.synthetic.main.activity_login.*


class LoginActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Go to register LoginActivity and this tv_register is ID under button LOGIN

        btn_forgotPass.setOnClickListener{
            val intent = Intent(this, ResetPasswordActivity::class.java)
            startActivity(intent)
        }

        tv_register.setOnClickListener {
            startActivity(Intent(this@LoginActivity, RegisterActivity::class.java))
        }

        //Button login

        btn_login.setOnClickListener {
            when {
                TextUtils.isEmpty(et_login_email.text.toString().trim { it <= ' ' }) -> {

                    Toast.makeText(
                        this@LoginActivity,
                        "Please enter email", // This line you will see if you don't enter your email
                        Toast.LENGTH_SHORT
                    ).show()
                }

                TextUtils.isEmpty(et_login_password.text.toString().trim { it <= ' ' }) -> {

                    Toast.makeText(
                        this@LoginActivity,
                        "Please enter password",// This line you will see if you don't enter your password
                        Toast.LENGTH_SHORT
                    ).show()
                }
                else -> {
                    val email = et_login_email.text.toString().trim { it <= ' ' }
                    val password = et_login_password.text.toString()
                        .trim { it <= ' ' } // You must enter the correct data, when registering, otherwise it will be displayed

                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener { task ->

                            if (task.isSuccessful) {


                                Toast.makeText(
                                    this@LoginActivity,
                                    "Login Successfully", Toast.LENGTH_SHORT // Correct data
                                ).show()

                                val intent =
                                    Intent(this@LoginActivity, PanelActivity::class.java)
                                intent.flags =
                                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                intent.putExtra(
                                    "user_id",
                                    FirebaseAuth.getInstance().currentUser!!.uid
                                )

                                intent.putExtra("email_id", email)
                                startActivity(intent)
                                finish()
                            } else {
                                Toast.makeText(
                                    this@LoginActivity, task.exception!!.message.toString(),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                }
            }
        }

    }

    companion object {
        fun prepareIntent(context: Context) = Intent(context, LoginActivity::class.java) // Fragment to activity <-----
    }



}
